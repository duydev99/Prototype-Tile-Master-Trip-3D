using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GamePlay : MonoBehaviour
{
    [Header("<<Data>>")]
    public int _CurrentLevel;
    public ConfigData _ConfigData;
    public GameObject _BlockPrefab;
    public Image _ItemPrefab;
    public Transform _BlockSpawnPoint;
    public Transform _ItemSpawnPoint;
    public Camera _CameraGamePlay;
    public Dictionary<int, int> _Blocks;
    public List<int> _BlocksTemp;
    public bool _IsLose;
    public bool _IsWin;
    [Header("<<UI>>")]
    public Text _TextStar;
    public Text _TextTime;
    public Text _TextLevel;
    public Text _TextLoseStar;
    public Button _ButtonReplay;
    public Button _ButtonLoseExit;
    public Text _TextWinStar;
    public Button _ButtonNext;
    public Button _ButtonWinExit;
    public GameObject _Middle;
    [Header("<<TimeLine>>")]
    public int _Minutes = 0;
    public int _Seconds = 0;
    public float _FrameCount = 60f;
    public float _NextTime = 0;
    [Header("<<Audio>>")]
    public AudioSource _AudioGamePlay;
    public AudioSource _AudioGameLose;
    public AudioSource _AudioGameWin;
    public AudioSource _AudioGameClick;
    public AudioSource _AudioGameStar;

    private void Start()
    {
        SetupGUI();
        SetupGamePlay(_CurrentLevel, _ConfigData);
    }

    private void Update()
    {
        HandleGamePlay();
        CheckWin();
        GameOver();
        EndGame();
    }

    public virtual void GameOver()
    {
        if (_IsLose)
        {
            _Middle.SetActive(true);
            _Middle.transform.GetChild(0).gameObject.SetActive(true);
            _TextLoseStar.text = _TextStar.text;
            _AudioGamePlay.Stop();
            _AudioGameWin.Stop();
            if (!_AudioGameLose.isPlaying)
                _AudioGameLose.Play();
        }
    }

    public virtual void EndGame()
    {
        if (_IsWin)
        {
            _Middle.SetActive(true);
            _Middle.transform.GetChild(1).gameObject.SetActive(true);
            _TextWinStar.text = _TextStar.text;
            _AudioGamePlay.Stop();
            _AudioGameLose.Stop();
            if(!_AudioGameWin.isPlaying)
                _AudioGameWin.Play();
        }
    }

    public virtual void SetupGUI()
    {
        _Middle.SetActive(false);
        _Middle.transform.GetChild(0).gameObject.SetActive(false);
        _Middle.transform.GetChild(1).gameObject.SetActive(false);
        _ButtonReplay.onClick.AddListener(Replay);
        _ButtonNext.onClick.AddListener(NextGame);
        _ButtonLoseExit.onClick.AddListener(Exit);
        _ButtonWinExit.onClick.AddListener(Exit);
    }

    public virtual void Replay()
    {
        _AudioGameClick.Play();
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public virtual void NextGame()
    {
        _AudioGameClick.Play();
        var nextIdx = _CurrentLevel;
        if(SceneManager.GetSceneByBuildIndex(nextIdx) != null)
            SceneManager.LoadScene(nextIdx);
    }

    public virtual void Exit()
    {
        _AudioGameClick.Play();
        Application.Quit();
    }

    public virtual void SetupGamePlay(int level, ConfigData config)
    {
        var data = config._Data.Find(x => x._Level == level);
        if (data == null) return;
        _IsLose = false;
        _IsWin = false;
        _Blocks = new Dictionary<int, int>();
        _BlocksTemp = new List<int>();
        _TextLevel.text = "Lv." + data._Level.ToString();
        var count = 0;
        while(count < data._BlockCount)
        {
            var imgIdx = Random.Range(0, data._Blocks.Count);
            SpawnBlocks(_BlockPrefab, data._Blocks[imgIdx]._Image, _BlockSpawnPoint, data._Blocks[imgIdx]._Id);
            count += 3;
            if (!_Blocks.ContainsKey(data._Blocks[imgIdx]._Id))
                _Blocks.Add(data._Blocks[imgIdx]._Id, 3);
            else
                _Blocks[data._Blocks[imgIdx]._Id] += 3;
        }
        _Minutes = data._Minute <= 0 ? 0 : data._Minute;
        _Seconds = data._Second > 60 ? 60 : data._Second;
        StartCoroutine(UpdateTimeLine(_TextTime));
    }

    public virtual void CheckWin()
    {
        if(_Blocks.Count <= 0) 
            _IsWin = true;
    }

    IEnumerator UpdateTimeLine(Text txt)
    {
        while(_Minutes >= 0)
        {
            if (_Minutes <= 0 && _Seconds <= 0)
            {
                UpdateTimeGUI(txt, 0, 0);
                break;
            }
            _Seconds -= 1;
            if (_Seconds <= 0) { _Seconds = 59; _Minutes -= 1; }
            UpdateTimeGUI(txt, _Minutes, _Seconds);
            yield return new WaitForSeconds(1f);
            
        }
    }

    public virtual void UpdateTimeGUI(Text txt, int minutes, int seconds)
    {
        _TextTime.text = minutes + " : " + seconds;
    }

    public virtual void SpawnBlocks(GameObject block, Sprite image, Transform spawnPoint, int id)
    {
        for(var idx = 0; idx < 3; idx++)
        {
            var x = Random.Range(-5f, 5f);
            var z = Random.Range(-5f, 5f);
            var newPoint = new Vector3(spawnPoint.position.x + x, spawnPoint.position.y, spawnPoint.position.z + z);
            var newObj = Instantiate(block, newPoint, Quaternion.identity);
            newObj.name = id.ToString();
            var face1 = newObj.transform.GetChild(0).GetComponent<MeshRenderer>().material;
            var face2 = newObj.transform.GetChild(1).GetComponent<MeshRenderer>().material;
            face1.mainTexture = image.texture;
            face2.mainTexture = image.texture;
        }
    }

    public virtual void HandleGamePlay()
    {
        if (Input.touchCount > 0 && Input.touches[0].phase == TouchPhase.Began)
        {
            if (_BlocksTemp.Count < 7)
            {
                Ray ray = _CameraGamePlay.ScreenPointToRay(Input.touches[0].position);
                RaycastHit hit;
                if (Physics.Raycast(ray, out hit))
                {
                    if (hit.transform.CompareTag("BlockItem"))
                    {
                        _AudioGameClick.Play();
                        var id = int.Parse(hit.transform.name.Trim());
                        _BlocksTemp.Add(id);

                        var blocks = _BlocksTemp.FindAll(x => x == id);

                        if (blocks.Count == 3)
                        {
                            foreach (var block in blocks)
                            {
                                _BlocksTemp.Remove(block);
                            }

                            _Blocks[id] -= 3;
                            if (_Blocks[id] <= 0)
                                _Blocks.Remove(id);

                            IncreaseStar(_TextStar, 3);
                            _AudioGameStar.Play();
                        }
                        Destroy(hit.transform.gameObject);
                        UpdateGamePlayGUI();
                    }
                }
            }
            else
            {
                if(_Blocks.Count > 0) 
                    _IsLose = true;
            }
        }
    }

    public virtual void UpdateGamePlayGUI()
    {
        foreach(Transform child in _ItemSpawnPoint.transform)
        {
            if (child.childCount > 0) 
                Destroy(child.GetChild(0).gameObject);
        }
        for(var idx = 0; idx < _BlocksTemp.Count; idx++)
        {
            var data = _ConfigData._Data.Find(x => x._Level == _CurrentLevel);
            var blockInfo = data._Blocks.Find(x => x._Id == _BlocksTemp[idx]);
            var newObj = Instantiate(_ItemPrefab, _ItemSpawnPoint.GetChild(idx));
            newObj.GetComponent<Image>().sprite = blockInfo._Image;
        }
    }

    public virtual void IncreaseStar(Text txt, int star)
    {
        txt.text = (int.Parse(txt.text.Trim()) + star).ToString();
    }
}
