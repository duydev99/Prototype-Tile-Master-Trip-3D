
using System;
using UnityEngine;
[Serializable]
public class BlockInfo
{
    public int _Id;
    public Sprite _Image;
}
