using System;
using System.Collections.Generic;

[Serializable]
public class Config
{
    public int _Level;
    public int _Minute;
    public int _Second;
    public int _BlockCount;
    public List<BlockInfo> _Blocks;
}
